// C++ 프로그래밍
// 서울지역대학 화상강의(ZOOM6)
// 학번: 202134-365538
// 이름: 천지영

#include	<iostream>
using namespace std; //using을 이용해서 namespace std를 간소화하여 사용할 수 있음

int main()
{
    cout << "나의 첫 번째 C++ 프로그램" << endl;
    return 0;
}



